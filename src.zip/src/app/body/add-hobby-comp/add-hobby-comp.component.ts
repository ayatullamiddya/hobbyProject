import { Component, OnInit } from '@angular/core';
import { HobbyServiceService } from 'src/app/myservice/hobby-service.service';

@Component({
  selector: 'app-add-hobby-comp',
  templateUrl: './add-hobby-comp.component.html',
  styleUrls: ['./add-hobby-comp.component.css']
})
export class AddHobbyCompComponent implements OnInit {
  HobbyArray : String[] = [];
  inputValue: String | undefined;
  constructor( private myservice:HobbyServiceService) { }
 
  ngOnInit(): void {
  }
  addHobby(input:any,event:any){
   
    console.log("add comp "+ input);
    this.HobbyArray.push(input);
    localStorage.setItem("hobbies",JSON.stringify(this.HobbyArray));
    // this.myservice.receiveData(this.HobbyArray);
  }
}


