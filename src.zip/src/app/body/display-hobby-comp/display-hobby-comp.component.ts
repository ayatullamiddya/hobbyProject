import { Component, OnInit } from '@angular/core';
import { HobbyServiceService } from 'src/app/myservice/hobby-service.service';

@Component({
  selector: 'app-display-hobby-comp',
  templateUrl: './display-hobby-comp.component.html',
  styleUrls: ['./display-hobby-comp.component.css']
})
export class DisplayHobbyCompComponent implements OnInit {
  HobbyArray : String[] = [];
  constructor(private myservice:HobbyServiceService) { 
   myservice.hobbyDisplayCom = this;
  }

  ngOnInit(): void {
  }
  display(){
    console.log("display-comp");
  //   this.HobbyArray = this.myservice.sendData();
  //  console.log( this.HobbyArray)
     let data =  localStorage.getItem("hobbies");
     console.log(data);
  }
 

}
